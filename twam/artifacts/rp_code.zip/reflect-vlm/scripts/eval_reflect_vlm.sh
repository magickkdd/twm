#!/bin/bash
set -eo pipefail

dynamics_model="${1:-sim}"
if (( $# > 0 )); then
    shift
fi

case "$dynamics_model" in
    sim) diffusion_args=() ;;
    diffusion) diffusion_args=(--diffuser_pretrained_model=yunhaif/ReflectVLM-diffusion) ;;
    *) printf 'Usage: %s {sim|diffusion} [run.py flags]\n' "$0" >&2; exit 1 ;;
esac

repo_dir="$(cd "$(dirname "$0")/.." && pwd)"
save_dir="$(dirname "$repo_dir")/runs/reflect_${dynamics_model}_$(date +%m%d_%H%M%S)"
for arg in "$@"; do
    if [[ "$arg" == --save_dir=* ]]; then
        save_dir="${arg#--save_dir=}"
    fi
done
mkdir -p "$save_dir"

export MUJOCO_GL="${MUJOCO_GL:-egl}"
export PYOPENGL_PLATFORM="$MUJOCO_GL"

echo "Save directory: $save_dir"
cd "$repo_dir"
python -u run.py \
    --seed=42 \
    --n_trajs=1 \
    --max_steps=10 \
    --save_dir="$save_dir" \
    --start_traj_id=0 \
    --start_board_id=42 \
    --logging.online=False \
    --agent_type=discovery \
    --revise_action=True \
    --imagine_future_steps=1 \
    "${diffusion_args[@]}" \
    --level=medium \
    --oracle_prob=0 \
    --model_path="${DISCOVERY_MODEL:-sensenova-6.8-flash-lite}" \
    --record=True \
    --record_frame_skip=1 \
    "$@" 2>&1 | tee "$save_dir/run.log"
